/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package metier;

import dao.ICotisationDao; 
import dao.IEmployeDao;
import exception.PamException; 
import java.util.List;
import jpa.Cotisation;
import jpa.Employe;
import jpa.Indemnite;
import org.springframework.transaction.annotation.Transactional;
/**
 *
 * @author j.fasquel
 */
//l'annotation Spring @Transactional fait que chaque méthode de la classe se déroulera au sein d'une transaction.
@Transactional
public class Metier implements IMetier {
// références sur la couche [dao]: instancie par configuration (properties) du bean "metier" dans spring-...-config.xml
private ICotisationDao cotisationDao = null; 
private IEmployeDao employeDao = null;
// obtenir la feuille de salaire
@Override
public FeuilleSalaire calculerFeuilleSalaire(String SS, double nbHeuresTravaillees, int nbJoursTravailles)
{
try
{
Employe employe=employeDao.find(SS);
Indemnite indemnite=employe.getIndemniteId();
Cotisation cotisation = cotisationDao.findAll().get(0);
// Calculs
double salaireBase=nbHeuresTravaillees*indemnite.getBaseHeure()*(1+indemnite.getIndemnitesCp()/100);
double cotisationsSociales=salaireBase*(cotisation.getCsgd()+cotisation.getCsgrds()+cotisation.getSecu()+cotisation.getRetraite())/100;
double indemnitesEntretien=nbJoursTravailles*indemnite.getEntretienJour();
double indemnitesRepas=nbJoursTravailles*indemnite.getRepasJour();
double salaireNet=salaireBase-cotisationsSociales+indemnitesEntretien+indemnitesRepas;

ElementsSalaire elts=new ElementsSalaire(salaireBase,cotisationsSociales,indemnitesEntretien,indemnitesRepas,salaireNet);

FeuilleSalaire feuille=new FeuilleSalaire(employe,cotisation,elts);
return feuille;
}
catch (Throwable th)
{
    throw new PamException("Employe de numero SS "+ SS + " not found",101); 
}
}
// liste des employés
@Override
public List<Employe> findAllEmployes() 
{
    return employeDao.findAll();   
}
// getters et setters
public void setCotisationDao(ICotisationDao cot) {this.cotisationDao=cot;}
public void setEmployeDao(IEmployeDao emp) {this.employeDao=emp;}
//... 
}