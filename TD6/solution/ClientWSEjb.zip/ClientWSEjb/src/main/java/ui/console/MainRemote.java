/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ui.console;
import pam.ws.FeuilleSalaire;
import pam.ws.PamWsEjbMetier;
import pam.ws.PamWsEjbMetierService;

public class MainRemote {
public static void main(String[] args) 
{
// c'est bon - on peut demander la feuille de salaire
String ss="260124402111742";
double heures=30;
int jours=5;
FeuilleSalaire feuilleSalaire;
try 
{
PamWsEjbMetierService metier_service=new PamWsEjbMetierService();
PamWsEjbMetier metier=metier_service.getPamWsEjbMetierPort();
feuilleSalaire=metier.calculerFeuilleSalaire("260124402111742", 30, 5);
} catch (Exception ex) {
System.err.println(String.format("L'erreur suivante s'est produite autre : %s", ex));
return;
}

// affichage détaillé
String output = "Valeurs saisies :\n";
output += ajouteInfo("N° de sécurité sociale de l'employé", ss);
output += ajouteInfo("Nombre d'heures travaillées", Double.toString(heures));
output += ajouteInfo("Nombre de jours travaillés", Integer.toString(jours));
output += ajouteInfo("\nInformations Employé", "");
output += ajouteInfo("Nom", feuilleSalaire.getEmploye().getNom());
output += ajouteInfo("Prénom", feuilleSalaire.getEmploye().getPrenom());
output += ajouteInfo("Adresse", feuilleSalaire.getEmploye().getAdresse());
output += ajouteInfo("Ville", feuilleSalaire.getEmploye().getVille());
output += ajouteInfo("Code Postal", feuilleSalaire.getEmploye().getCp());
output += ajouteInfo("Indice", "" + feuilleSalaire.getEmploye().getIndemniteId().getIndice());
output += ajouteInfo("\nInformations Cotisations", "");
output += ajouteInfo("CSGRDS", "" + feuilleSalaire.getCotisation().getCsgrds() + " %");
output += ajouteInfo("CSGD", "" + feuilleSalaire.getCotisation().getCsgd() + " %");
output += ajouteInfo("Retraite", "" + feuilleSalaire.getCotisation().getRetraite() + " %");
output += ajouteInfo("Sécurité sociale", "" + feuilleSalaire.getCotisation().getSecu() + " %");
output += ajouteInfo("\nInformations Indemnités", "");
output += ajouteInfo("Salaire horaire", "" + feuilleSalaire.getEmploye().getIndemniteId().getBaseHeure() + " euro");
output += ajouteInfo("Entretien/jour", "" + feuilleSalaire.getEmploye().getIndemniteId().getEntretienJour() + " euro");
output += ajouteInfo("Repas/jour", "" + feuilleSalaire.getEmploye().getIndemniteId().getRepasJour() + " euro");
output += ajouteInfo("Congés Payés", "" + feuilleSalaire.getEmploye().getIndemniteId().getIndemnitesCp() + " %");
output += ajouteInfo("\nInformations Salaire", "");
output += ajouteInfo("Salaire de base", "" + feuilleSalaire.getElementsSalaire().getSalaireBase() + " euro");
output += ajouteInfo("Indemnités de repas", "" + feuilleSalaire.getElementsSalaire().getIndemnitesRepas() + " euro");
output += ajouteInfo("Salaire net", "" + feuilleSalaire.getElementsSalaire().getSalaireNet() + " euro");

System.out.println(output);

}

static String ajouteInfo(String message, String valeur) {
return String.format("%s : %s\n", message, valeur);
}
}