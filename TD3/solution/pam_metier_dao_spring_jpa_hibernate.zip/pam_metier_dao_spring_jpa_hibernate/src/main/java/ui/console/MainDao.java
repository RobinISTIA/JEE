/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ui.console;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import dao.ICotisationDao;
import dao.IEmployeDao;
import java.util.List;
import jpa.Cotisation;
import jpa.Employe;
/**
 *
 * @author j.fasquel
 */
public class MainDao {
public static void main(String[] args) 
{
// configuration de l'application
ApplicationContext ctx = new ClassPathXmlApplicationContext("spring-config-metier-dao.xml");
// CotisationDao
ICotisationDao cotisationDao = (ICotisationDao) ctx.getBean("cotisationDao");
List<Cotisation> cotisations = cotisationDao.findAll();
for ( Cotisation c : cotisations) { System.out.println("Cotisation: "+c); }
// EmployeDao
IEmployeDao employeDao = (IEmployeDao) ctx.getBean("employeDao");
List<Employe> employes = employeDao.findAll();
for ( Employe e : employes) { System.out.println("Employe: "+e); }
// Test creation nouvel employe
Cotisation c = new Cotisation(null, 8.15,3.49,7.88,9.39,  1);
c = cotisationDao.create(c);


}
}
